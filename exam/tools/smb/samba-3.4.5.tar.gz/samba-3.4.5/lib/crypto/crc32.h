uint32_t crc32_calc_buffer(const uint8_t *buf, size_t size);
