/* Copyright (c): 2002-2005 (Germany): United Internet, 1&1, GMX, Schlund+Partner, Alturo */
function QxToolBar(){QxWidget.call(this);this.setHeight("auto");};QxToolBar.extend(QxWidget,"QxToolBar");